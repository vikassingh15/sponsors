create trigger before_candidate_insert
  before INSERT
  on candidates
  for each row
  SET
    NEW.created_at = IFNULL(NEW.created_at, NOW()),
    NEW.activations_code_expiration = TIMESTAMPADD(DAY, 14, NEW.created_at);

